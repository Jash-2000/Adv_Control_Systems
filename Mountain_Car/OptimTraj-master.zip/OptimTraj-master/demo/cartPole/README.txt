README.txt  --  Cart-Pole

This directory contains code to compute the optimal swing-up trajectory for a cart-pole system, minimizing torque-squared.

Run the example using MAIN.m

Derive equations of motion using Derive_cartPole.m

